 # -*- coding: utf-8 -*- 

import base64, codecs
import xbmcaddon

MainBase = base64.b64decode('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0ZhdC1ib3ktc2ltL1RWL21haW4vbWVudQ==')
addon = xbmcaddon.Addon('plugin.video.MinionTV')